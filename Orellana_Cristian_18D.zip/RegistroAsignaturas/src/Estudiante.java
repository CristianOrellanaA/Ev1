/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Estudiante {
    
    private String rut,nombre,fechaNacimiento;
    private int edad;

    public Estudiante() {
    }

    public Estudiante(String rut, String nombre, String fechaNacimiento, int edad) {
        this.rut = rut;
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.edad = edad;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre.length()>0) {
            this.nombre = nombre;
        } else {
            System.out.println("NOMBRE DEBE SER MAYOR A 0 CARACTERES");
        }
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
        if (edad>=18 && edad<100) {
            this.edad = edad;
        } else {
            System.out.println("EDAD DEBE SER MAYOR O IGUAL A 18 E INFERIOR A 100");
        }
    }

    @Override
    public String toString() {
        return "Estudiante{" + "rut=" + rut + ", nombre=" + nombre + ", fechaNacimiento=" + fechaNacimiento + ", edad=" + edad + '}';
    }
    
    
}
