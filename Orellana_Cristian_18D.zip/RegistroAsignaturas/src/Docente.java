/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Docente {
    
    private String rut,nombre,fechaIngreso,sede;
    private int nroDocente;

    public Docente() {
    }

    public Docente(String rut, String nombre, String fechaIngreso, String sede, int nroDocente) {
        this.rut = rut;
        this.nombre = nombre;
        this.fechaIngreso = fechaIngreso;
        this.sede = sede;
        this.nroDocente = nroDocente;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre.length()>0) {
            this.nombre = nombre;
        } else {
            System.out.println("NOMBRE DEBE SER MAYOR A 0 CARACTERES");
        }
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }

    public int getNroDocente() {
        return nroDocente;
    }

    public void setNroDocente(int nroDocente) {
        this.nroDocente = nroDocente;
    }

    @Override
    public String toString() {
        return "Docente{" + "rut=" + rut + ", nombre=" + nombre + ", fechaIngreso=" + fechaIngreso + ", sede=" + sede + ", nroDocente=" + nroDocente + '}';
    }
    
    
}
