/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Sede {
    
    private String nombre,comuna;
    private int nroSede;

    public Sede() {
    }

    public Sede(String nombre, String comuna, int nroSede) {
        this.nombre = nombre;
        this.comuna = comuna;
        this.nroSede = nroSede;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getComuna() {
        return comuna;
    }

    public void setComuna(String comuna) {
        this.comuna = comuna;
    }

    public int getNroSede() {
        return nroSede;
    }

    public void setNroSede(int nroSede) {
        this.nroSede = nroSede;
    }

    @Override
    public String toString() {
        return "Sede{" + "nombre=" + nombre + ", comuna=" + comuna + ", nroSede=" + nroSede + '}';
    }
    
    
}
