/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Asignatura {
    
    private String codigo,nombre;
    private double nota1,nota2,nota3,notaExamen;
    private Estudiante estudiante;
    private Docente docente;

    public Asignatura() {
    }

    public Asignatura(String codigo, String nombre, double nota1, double nota2, double nota3, double notaExamen, Estudiante estudiante, Docente docente) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
        this.notaExamen = notaExamen;
        this.estudiante = estudiante;
        this.docente = docente;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getNota1() {
        return nota1;
    }

    public void setNota1(double nota1) {
        this.nota1 = nota1;
    }

    public double getNota2() {
        return nota2;
    }

    public void setNota2(double nota2) {
        this.nota2 = nota2;
    }

    public double getNota3() {
        return nota3;
    }

    public void setNota3(double nota3) {
        this.nota3 = nota3;
    }

    public double getNotaExamen() {
        return notaExamen;
    }

    public void setNotaExamen(double notaExamen) {
        this.notaExamen = notaExamen;
    }

    public Estudiante getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public Docente getDocente() {
        return docente;
    }

    public void setDocente(Docente docente) {
        this.docente = docente;
    }

    @Override
    public String toString() {
        return "Asignatura{" + "codigo=" + codigo + ", nombre=" + nombre + ", nota1=" + nota1 + ", nota2=" + nota2 + ", nota3=" + nota3 + ", notaExamen=" + notaExamen + ", estudiante=" + estudiante + ", docente=" + docente + '}';
    }
  
    
    public double notaPresentacion(){
        double presentacion =0;
        presentacion+=nota1*0.30;
        presentacion+=nota2*0.30;
        presentacion+=nota3*0.40;
        return presentacion;
    }
    
    public void eximicion(){
        if (notaPresentacion()>=5.0) {
            System.out.println("ALUMNO EXIMIDO DE LA ASIGNATURA");            
        } else {
            System.out.println("NOTA INSUFICIENTE, ALUMNO NO QUEDA EXIMIDO");
        }
    }
    
    public float notaFinal(double notaExamen){
        float notaTotal=0;
        notaTotal+=(notaPresentacion()*0.60)+(notaExamen*0.40);
        return notaTotal;
    }
    
    public void estadoEstudiante(float notaTotal){
        if (notaTotal>=4.0 && notaTotal<=7.0) {
            System.out.println("ESTADO DEL ALUMNO: APROBADO");
        } else {
            System.out.println("ESTADO DEL ALUMNO: REPROBADO");
        }
    }
}
