/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Test {
    
    public static void main(String[] args) {
        
        Estudiante estudiante1 = new Estudiante("196146245","Cristian","16/12/1997",18);
        Docente docente1 = new Docente("106245976","Jorge","24/06/2014","Viña del mar",032);
        Docente docente2 = new Docente("168432548","Alejandro","31/08/2017","Viña del mar",056);
        Sede sede1 = new Sede("Duoc viña del mar","Viña del mar",29);
        Asignatura asignatura1 = new Asignatura("MAT1","Matematicas",4.3,6.2,5.8,5.6,estudiante1,docente1);
        Asignatura asignatura2 = new Asignatura("PROG1","Programacion",3.6,5.7,6.8,6.3,estudiante1,docente2);
        System.out.println("Codigo Asignatura: "+asignatura1.getCodigo());
        System.out.println("Asignatura: "+asignatura1.getNombre());
        System.out.println("Docente: "+docente1.getNombre());
        System.out.println("Alumno: "+estudiante1.getNombre());
        System.out.println("Nota 1: "+asignatura1.getNota1());
        System.out.println("Nota 2: "+asignatura1.getNota2());
        System.out.println("Nota 3: "+asignatura1.getNota3());
        System.out.println("Nota examen: "+asignatura1.getNotaExamen());
        System.out.println("Nota Final: "+asignatura1.notaFinal(5.6));
        
        System.out.println("Codigo Asignatura: "+asignatura2.getCodigo());
        System.out.println("Asignatura: "+asignatura2.getNombre());
        System.out.println("Docente: "+docente2.getNombre());
        System.out.println("Alumno: "+estudiante1.getNombre());
        System.out.println("Nota 1: "+asignatura2.getNota1());
        System.out.println("Nota 2: "+asignatura2.getNota2());
        System.out.println("Nota 3: "+asignatura2.getNota3());
        System.out.println("Nota examen: "+asignatura2.getNotaExamen());
        System.out.println("Nota Final: "+asignatura2.notaFinal(6.3));

        
    }
}
